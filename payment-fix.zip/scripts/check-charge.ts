/**
 * Diagnosis charge Midtrans dari LUAR Worker: mencoba membuat transaksi sandbox untuk SETIAP metode
 * memakai payload yang SAMA persis dengan aplikasi (buildChargeBody), lalu membatalkannya.
 *
 *   MIDTRANS_SERVER_KEY=SB-Mid-server-xxxx npx tsx scripts/check-charge.ts [sandbox|production]
 *
 * Server Key hanya dibaca dari environment lokal dan TIDAK dicetak.
 * Cara membaca hasil per metode:
 *   201            -> kanal aktif & payload valid.
 *   402            -> kanal BELUM aktif di akun Midtrans (aktifkan / minta aktivasi; bukan bug kode).
 *   400 + pesan    -> payload ditolak; "validation" menyebut field yang salah.
 *   401            -> Server Key salah / tidak cocok dengan environment.
 */
import { buildChargeBody, formatWib, type ChargeMethod } from "../worker/src/midtrans";

const KEY = (process.env.MIDTRANS_SERVER_KEY || "").trim();
if (!KEY) { console.error("Set MIDTRANS_SERVER_KEY di environment lokal (jangan ditempel ke chat)."); process.exit(2); }
const mode = process.argv[2] === "production" ? "production" : "sandbox";
if (mode === "sandbox" && !KEY.startsWith("SB-")) { console.error("Mode sandbox tetapi Server Key bukan key Sandbox (SB-Mid-server-...)."); process.exit(2); }
const API = mode === "production" ? "https://api.midtrans.com" : "https://api.sandbox.midtrans.com";
const AUTH = "Basic " + Buffer.from(KEY + ":").toString("base64");

const METHODS: ChargeMethod[] = ["bni_va", "bri_va", "permata_va", "mandiri_bill", "qris", "gopay"];

async function call(path: string, body?: unknown) {
  const r = await fetch(API + path, {
    method: body === undefined ? "GET" : "POST",
    headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: AUTH },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  return (await r.json().catch(() => ({}))) as Record<string, any>;
}

for (const method of METHODS) {
  const orderId = `SC000000-T${Date.now().toString(36).toUpperCase().slice(-7)}`;
  const body = buildChargeBody({
    orderId, grossAmount: 99000, method,
    items: [{ id: "diagnosis", price: 99000, quantity: 1, name: "Template Diagnosis" }],
    customer: { first_name: "Tes Diagnosis", email: "tes@example.com" },
    expiryStartWib: formatWib(new Date()), expiryMinutes: 24 * 60,
    gopayCallbackUrl: "https://studio.satucerita.app/order/" + orderId,
    billLabel: "Template Diagnosis",
  });
  const res = await call("/v2/charge", body);
  console.log(`\n[${method}] status_code=${res.status_code} :: ${res.status_message ?? ""}`);
  if (res.validation_messages) console.log("  validation:", res.validation_messages);
  if (res.status_code === "201") { await call(`/v2/${orderId}/cancel`, {}); console.log("  (transaksi uji dibatalkan)"); }
  await new Promise((r) => setTimeout(r, 400));
}
