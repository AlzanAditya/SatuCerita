import { listOrders } from "@/lib/payments";
import React, { useState, useEffect, useMemo, useRef, useCallback } from "react";
import { PATHS } from "@/routes";
import {
  Home,
  ShoppingBag,
  UserRound,
  SquareArrowOutUpRight,
  Plus,
  LogOut,
  X,
  LayoutGrid,
  ZoomIn,
  Crop,
} from "lucide-react";
import { AppNavbar } from "@/components/app/AppNavbar";
import { Button } from "@/components/ui/Button";
import { AppSidebar } from "@/components/AppSidebar";
import { ImageCropModal } from "@/components/ImageCropModal";
import { getCache, setCache, convertFileToDataUrl, UserProfileData } from "@/lib/cache";
import { useAuth } from "@/context/AuthContext";
import { avatarFallback, formatMemberSince, updateProfile } from "@/lib/auth";
import { UndanganPage } from "./UndanganPage";
import { PesananPage } from "./PesananPage";
import { ProfilePage } from "./ProfilePage";
import { CheckoutPage } from "./CheckoutPage";
import { OrderDetailPage } from "./OrderDetailPage";
import { UserAppProps, UserInvitation, OrderItem } from "./types";

export * from "./types";

export const UserApp: React.FC<UserAppProps> = ({
  activeTab: propActiveTab = "home",
  onNavigate,
  currentPath = "/app/home",
}) => {
  const isStandalone = useMemo(
    () => typeof window !== "undefined" && window.location.hostname.startsWith("app."),
    []
  );
  const prefix = isStandalone ? "" : "/app";

  // Determine current active tab
  const activeTab = useMemo(() => {
    if (propActiveTab) {
      if (
        propActiveTab === "task" ||
        propActiveTab === "bayar" ||
        propActiveTab === "pesanan"
      ) {
        return "proses";
      }
      return propActiveTab;
    }
    if (
      currentPath.includes("/proses") ||
      currentPath.includes("/task") ||
      currentPath.includes("/pesanan") ||
      currentPath.includes("/bayar")
    ) {
      return "proses";
    }
    if (currentPath.includes("/profile") || currentPath.includes("/profil")) {
      return "profile";
    }
    if (currentPath.includes("/checkout")) return "checkout";
    if (currentPath.includes("/order")) return "order";
    return "home";
  }, [propActiveTab, currentPath]);

  // Selected Order for Detail View
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);

  // User Profile
  const { user, setUser, signOut } = useAuth();
  const avatarKey = `satucerita_avatar_${user.id}`;
  const [avatarOverride, setAvatarOverride] = useState<string>(() => getCache<string>(avatarKey, ""));
  const userProfile: UserProfileData = {
    name: user.name,
    email: user.email,
    phone: user.phone,
    avatar: avatarOverride || user.avatar || avatarFallback(user.name),
    memberSince: formatMemberSince(user.createdAt),
  };

  const [isEditProfileOpen, setIsEditProfileOpen] = useState(false);
  const [editName, setEditName] = useState(userProfile.name);
  const [editPhone, setEditPhone] = useState(userProfile.phone);
  const [editAvatarUrl, setEditAvatarUrl] = useState(userProfile.avatar);

  // ========== TASK 5: Crop Modal State ==========
  const [isCropModalOpen, setIsCropModalOpen] = useState(false);
  const [cropImageSrc, setCropImageSrc] = useState<string>("");

  const openCropModal = async (file: File) => {
    try {
      const dataUrl = await convertFileToDataUrl(file);
      setCropImageSrc(dataUrl);
      setIsCropModalOpen(true);
    } catch (_err) {
      showToast("Gagal membaca file gambar.");
    }
  };

  // Logout Confirmation Modal
  const [isLogoutModalOpen, setIsLogoutModalOpen] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);

  // Toast Notice
  const [toastNotice, setToastNotice] = useState<string | null>(null);
  const showToast = (msg: string) => {
    setToastNotice(msg);
    setTimeout(() => setToastNotice(null), 3000);
  };

  // Invitations State
  const [invitations, setInvitations] = useState<UserInvitation[]>(() => {
    if (typeof window !== "undefined") {
      try {
        const saved = localStorage.getItem("satucerita_invitations_v2");
        if (saved) return JSON.parse(saved);
      } catch (_e) {}
    }
    return [];
  });

  useEffect(() => {
    if (typeof window !== "undefined") {
      try {
        localStorage.setItem("satucerita_invitations_v2", JSON.stringify(invitations));
      } catch (_e) {}
    }
  }, [invitations]);

  // Orders State — sumber kebenaran = server (Supabase lewat Worker). Tidak lagi disimpan di localStorage,
  // jadi status "lunas" tidak bisa dipalsukan dari browser.
  const [orders, setOrders] = useState<OrderItem[]>([]);

  const upsertOrder = (order: OrderItem) => {
    setOrders((prev) => {
      const i = prev.findIndex((o) => o.invoiceNo === order.invoiceNo);
      if (i === -1) return [order, ...prev];
      const next = prev.slice();
      next[i] = order;
      return next;
    });
  };

  useEffect(() => {
    let alive = true;
    // Hapus sisa data pesanan tiruan dari versi lama (tidak dipakai lagi).
    try { localStorage.removeItem("satucerita_orders_v2"); } catch (_e) {}
    listOrders().then((res) => {
      if (alive && res.ok && Array.isArray(res.data.orders)) setOrders(res.data.orders);
    });
    return () => { alive = false; };
  }, []);

  // Save profile changes
  const saveTimer = useRef<number>(0);
  const saveSeq = useRef(0);
  const handleInlineProfileUpdate = (u: UserProfileData) => {
    window.clearTimeout(saveTimer.current);
    const seq = ++saveSeq.current;
    saveTimer.current = window.setTimeout(async () => {
      const hasPhone = u.phone.replace(/\D/g, "").replace(/^62/, "").length > 0;
      const res = await updateProfile({ name: u.name, phone: hasPhone ? u.phone : "" });
      if (seq !== saveSeq.current) return;
      if (res.ok && res.user) setUser(res.user);
      else showToast(res.error || "Gagal menyimpan profil.");
    }, 900);
  };

  const handleSaveProfile = async () => {
    const res = await updateProfile({ name: editName, phone: editPhone });
    if (!res.ok || !res.user) {
      showToast(res.error || "Gagal menyimpan profil.");
      return;
    }
    setUser(res.user);
    if (editAvatarUrl && editAvatarUrl !== userProfile.avatar) {
      setAvatarOverride(editAvatarUrl);
      setCache(avatarKey, editAvatarUrl);
    }
    setIsEditProfileOpen(false);
    showToast("Profil berhasil diperbarui!");
  };

  // Perform logout
  const handlePerformLogout = async () => {
    setIsLogoutModalOpen(false);
    await signOut();
    window.location.replace(PATHS.home);
  };

  // Avatar upload handler (opens crop modal)
  const handleAvatarFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      await openCropModal(file);
    }
    // Reset input so same file can be selected again
    e.target.value = "";
  };

  const handleCreateOrder = (order: OrderItem) => upsertOrder(order);

  // Determine App Bar Title
  const getAppNavbarTitle = () => {
    if (activeTab === "checkout") return "Checkout";
    if (activeTab === "order") return "Detail Pesanan";
    if (selectedOrderId) return "Detail Pesanan";
    if (activeTab === "home") return "Undangan";
    if (activeTab === "proses") return "Pesanan";
    if (activeTab === "profile") return "Profil Saya";
    return "Satu Cerita App";
  };

  // Pending orders count for notification
  const pendingOrdersCount = orders.filter((o) => o.status === "pending").length;

  // ===== Sidebar items =====
  const sidebarNavItems = [
    {
      id: "home",
      label: "Undangan Saya",
      icon: Home,
      isActive: !selectedOrderId && activeTab === "home",
      badge: invitations.length > 0 ? invitations.length : undefined,
      onClick: () => {
        setSelectedOrderId(null);
        onNavigate(`${prefix}/home`);
      },
    },
    {
      id: "proses",
      label: "Pesanan & Tagihan",
      icon: ShoppingBag,
      isActive: selectedOrderId != null || activeTab === "proses",
      badge: orders.filter((o) => o.status === "pending").length || undefined,
      onClick: () => {
        setSelectedOrderId(null);
        onNavigate(`${prefix}/pesanan`);
      },
    },
    {
      id: "profile",
      label: "Profil Akun",
      icon: UserRound,
      isActive: !selectedOrderId && activeTab === "profile",
      onClick: () => {
        setSelectedOrderId(null);
        onNavigate(`${prefix}/profile`);
      },
    },
    {
      id: "katalog",
      label: "Katalog Template",
      icon: LayoutGrid,
      isActive: false,
      onClick: () => {
        onNavigate(PATHS.katalog);
        window.scrollTo({ top: 0, behavior: "smooth" });
      },
    },
  ];

  const isCheckoutOrOrder = activeTab === "checkout" || activeTab === "order";

  return (
    <div className="min-h-screen bg-[#faf9ff] flex flex-col md:flex-row font-sans text-neutral-800 pb-20 md:pb-0 select-none">

      {/* DESKTOP SIDEBAR — use shared AppSidebar component (collapsible, logo satucerita, tanpa subjudul) */}
      {!isCheckoutOrOrder && (
        <AppSidebar
          logoSrc="/logos/satucerita.png"
          brandName={<>Satu<span className="text-[#7d6aee]">Cerita</span></>}
          onLogoClick={() => onNavigate(PATHS.home)}
          collapsible
          collapsed={isSidebarCollapsed}
          onToggleCollapse={() => setIsSidebarCollapsed((prev) => !prev)}
          navItems={sidebarNavItems}
          footerUser={{
            avatar: userProfile.avatar,
            name: userProfile.name,
            email: userProfile.email,
          }}
          onLogout={() => setIsLogoutModalOpen(true)}
        />
      )}

      {/* Main Container Right Side */}
      <div className="flex-1 min-w-0 flex flex-col justify-between">
        {/* Top Navbar (Mobile only) — hide on checkout/order to keep clean */}
        {!isCheckoutOrOrder && (
          <div className="md:hidden">
            <AppNavbar
              currentPath={currentPath}
              onNavigate={onNavigate}
              activeTab={activeTab}
              title={getAppNavbarTitle()}
              userProfile={{
                name: userProfile.name,
                email: userProfile.email,
                avatar: userProfile.avatar,
              }}
            />
          </div>
        )}

        {/* Desktop Top Header Bar */}
        {!isCheckoutOrOrder && (
          <header className="hidden md:flex items-center justify-between px-6 lg:px-8 py-4 bg-white border-b border-purple-50 shrink-0">
            <div>
              <h1 className="text-lg font-black text-neutral-900 tracking-tight">
                {getAppNavbarTitle()}
              </h1>
              <p className="text-xs text-neutral-400">
                {activeTab === "home" && "Kelola dan pantau undangan digital yang telah Anda buat."}
                {activeTab === "proses" && "Daftar pesanan aktif dan status proses verifikasi pembayaran."}
                {activeTab === "profile" && "Informasi akun dan pengaturan data kontak Satu Cerita."}
              </p>
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => {
                  onNavigate(PATHS.katalog);
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-50 hover:bg-purple-100 text-[#7d6aee] text-xs font-bold transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Buat Undangan Baru</span>
              </button>
            </div>
          </header>
        )}

        {/* Main Content Area */}
        <main className={`flex-1 w-full ${isCheckoutOrOrder ? "" : "max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-5 sm:py-6"} animate-fadeIn`}>
          {activeTab === "home" && (
            <UndanganPage
              invitations={invitations}
              onNavigate={onNavigate}
              showToast={showToast}
              pendingOrders={orders.filter((o) => o.status === "pending")}
            />
          )}

          {activeTab === "proses" && (
            <PesananPage
              orders={orders}
              selectedOrderId={selectedOrderId}
              setSelectedOrderId={setSelectedOrderId}
              onNavigate={onNavigate}
              showToast={showToast}
            />
          )}

          {activeTab === "profile" && (
            <ProfilePage
              userProfile={userProfile}
              onUpdateProfile={handleInlineProfileUpdate}
              onOpenEditModal={() => {
                setEditName(userProfile.name);
                setEditPhone(userProfile.phone);
                setEditAvatarUrl(userProfile.avatar);
                setIsEditProfileOpen(true);
              }}
              onOpenLogoutModal={() => setIsLogoutModalOpen(true)}
              onNavigate={onNavigate}
              invitationsCount={invitations.length}
              ordersCount={orders.length}
              rsvpCount={invitations.reduce((acc, i) => acc + i.guestCount, 0)}
            />
          )}

          {activeTab === "checkout" && (
            <CheckoutPage
              currentPath={currentPath}
              onNavigate={onNavigate}
              onCreateOrder={handleCreateOrder}
            />
          )}

          {activeTab === "order" && (
            <OrderDetailPage
              currentPath={currentPath}
              onNavigate={onNavigate}
              orders={orders}
              onOrderUpdate={upsertOrder}
              showToast={showToast}
            />
          )}

          {/* Global Toast */}
          {toastNotice && (
            <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-xl bg-neutral-900 text-white text-xs font-semibold shadow-xl animate-fadeIn flex items-center gap-2">
              <span>{toastNotice}</span>
            </div>
          )}
        </main>

        {/* Floating Bottom Nav (Mobile only) */}
        {!isCheckoutOrOrder && (
          <nav
            id="satucerita-app-bottom-navbar"
            className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 border-t border-purple-100 backdrop-blur-lg shadow-lg select-none"
            aria-label="Satu Cerita App Navigation"
          >
            <div className="max-w-md mx-auto grid grid-cols-4 h-16 px-1">
              <button
                type="button"
                onClick={() => {
                  setSelectedOrderId(null);
                  onNavigate(`${prefix}/home`);
                }}
                className={`flex flex-col items-center justify-center gap-0.5 transition-all cursor-pointer ${
                  !selectedOrderId && activeTab === "home"
                    ? "text-[#7d6aee] font-bold"
                    : "text-neutral-500 hover:text-neutral-900 font-semibold"
                }`}
                aria-label="Undangan"
              >
                <Home className="w-5 h-5" />
                <span
                  className={`text-[11px] leading-tight ${
                    !selectedOrderId && activeTab === "home"
                      ? "font-bold text-[#7d6aee]"
                      : "font-semibold"
                  }`}
                >
                  Undangan
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setSelectedOrderId(null);
                  onNavigate(`${prefix}/pesanan`);
                }}
                className={`flex flex-col items-center justify-center gap-0.5 transition-all cursor-pointer ${
                  selectedOrderId || activeTab === "proses"
                    ? "text-[#7d6aee] font-bold"
                    : "text-neutral-500 hover:text-neutral-900 font-semibold"
                }`}
                aria-label="Pesanan"
              >
                <ShoppingBag className="w-5 h-5" />
                <span
                  className={`text-[11px] leading-tight ${
                    selectedOrderId || activeTab === "proses"
                      ? "font-bold text-[#7d6aee]"
                      : "font-semibold"
                  }`}
                >
                  Pesanan
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setSelectedOrderId(null);
                  onNavigate(`${prefix}/profile`);
                }}
                className={`flex flex-col items-center justify-center gap-0.5 transition-all cursor-pointer ${
                  !selectedOrderId && activeTab === "profile"
                    ? "text-[#7d6aee] font-bold"
                    : "text-neutral-500 hover:text-neutral-900 font-semibold"
                }`}
                aria-label="Profil"
              >
                <UserRound className="w-5 h-5" />
                <span
                  className={`text-[11px] leading-tight ${
                    !selectedOrderId && activeTab === "profile"
                      ? "font-bold text-[#7d6aee]"
                      : "font-semibold"
                  }`}
                >
                  Profil
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  onNavigate(PATHS.home);
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }}
                className="flex flex-col items-center justify-center gap-0.5 transition-all cursor-pointer text-neutral-500 hover:text-neutral-900 font-semibold"
                aria-label="Kembali ke Landing Page"
              >
                <SquareArrowOutUpRight className="w-5 h-5" />
                <span className="text-[11px] leading-tight font-semibold">
                  Kembali
                </span>
              </button>
            </div>
          </nav>
        )}
      </div>

      {/* ===================== MODAL EDIT PROFIL ===================== */}
      {isEditProfileOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-fadeIn">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-purple-100 overflow-hidden flex flex-col">
            <div className="flex items-center justify-between px-6 pt-5 pb-4 border-b border-neutral-100">
              <h3 className="text-base font-bold text-neutral-900">Edit Profil</h3>
              <button
                type="button"
                onClick={() => setIsEditProfileOpen(false)}
                className="size-8 rounded-full hover:bg-neutral-100 flex items-center justify-center text-neutral-400 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              {/* Avatar with Crop */}
              <div className="flex flex-col items-center">
                <img
                  src={editAvatarUrl}
                  alt="Preview Avatar"
                  className="size-20 rounded-full object-cover border-2 border-[#7d6aee] shadow-sm mb-3"
                />
                <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-neutral-200 text-xs font-bold text-neutral-700 hover:bg-neutral-50 cursor-pointer shadow-2xs">
                  <Crop className="w-3.5 h-3.5 text-[#7d6aee]" />
                  <span>Upload & Potong Foto</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleAvatarFileUpload}
                    className="hidden"
                  />
                </label>
              </div>

              <div>
                <label className="text-xs font-semibold text-neutral-800 block mb-1">
                  Nama Lengkap
                </label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full bg-white border border-neutral-200 rounded-xl px-3.5 py-2 text-xs focus:outline-none focus:border-[#7d6aee]"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-neutral-800 block mb-1">
                  Email
                </label>
                <input
                  type="email"
                  value={userProfile.email}
                  disabled
                  readOnly
                  className="w-full bg-neutral-100 border border-neutral-200 text-neutral-500 rounded-xl px-3.5 py-2 text-xs cursor-not-allowed"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-neutral-800 block mb-1">
                  Nomor WhatsApp
                </label>
                <input
                  type="text"
                  value={editPhone}
                  onChange={(e) => setEditPhone(e.target.value)}
                  className="w-full bg-white border border-neutral-200 rounded-xl px-3.5 py-2 text-xs focus:outline-none focus:border-[#7d6aee]"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2.5 px-6 py-4 bg-neutral-50 border-t border-neutral-100">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsEditProfileOpen(false)}
              >
                Batal
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={handleSaveProfile}
              >
                Simpan
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* ===================== CROP MODAL ===================== */}
      <ImageCropModal
        isOpen={isCropModalOpen}
        imageSrc={cropImageSrc}
        onClose={() => setIsCropModalOpen(false)}
        onApplyCrop={(croppedUrl) => {
          setEditAvatarUrl(croppedUrl);
        }}
      />

      {/* ===================== MODAL KONFIRMASI LOGOUT ===================== */}
      {isLogoutModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-fadeIn">
          <div className="w-full max-w-sm bg-white rounded-2xl shadow-2xl border border-neutral-100 overflow-hidden p-6 text-center">
            <div className="size-14 rounded-full bg-rose-50 text-rose-500 flex items-center justify-center mx-auto mb-3">
              <LogOut className="w-6 h-6" />
            </div>
            <h3 className="text-base font-extrabold text-neutral-900 tracking-tight">
              Yakin Ingin Keluar?
            </h3>
            <p className="text-xs text-neutral-500 font-medium mt-1 leading-relaxed">
              Anda akan keluar dari akun Satu Cerita dan diarahkan kembali ke beranda.
            </p>

            <div className="grid grid-cols-2 gap-2 mt-5">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsLogoutModalOpen(false)}
              >
                Batal
              </Button>
              <Button
                variant="danger"
                size="sm"
                onClick={handlePerformLogout}
              >
                Ya, Keluar
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserApp;
